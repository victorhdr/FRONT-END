// script.js para Ejemplo 1
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('btnSaludo');
  btn.addEventListener('click', () => {
    alert('¡Hola desde el front-end con JS!');
  });
});
