// script.js para Ejemplo 4
// Aquí podrías añadir validaciones extra del lado del cliente si quieres.
console.log('Ejemplo 4 - script.js cargado');
