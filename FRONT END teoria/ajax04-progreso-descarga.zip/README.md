# XHR progreso de descarga

Usa `xhr.onprogress` y `responseType = "blob"` para mostrar el avance y renderizar la imagen descargada.

**Nota**: el progreso sólo es porcentual si el servidor expone `Content-Length` (si no, verás bytes cargados).
