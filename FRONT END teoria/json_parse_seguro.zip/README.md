
# json_parse_seguro
Ejemplo de `JSON.parse()` con manejo de errores (`try/catch`). Incluye botón con casos inválidos comunes.
