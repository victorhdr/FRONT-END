
# json_api_simulada
Simula una respuesta de API en una función, la parsea con `reviver` para fechas y renderiza una tabla de usuarios.
