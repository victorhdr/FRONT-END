
'use strict';
function simularAPI(){
  return JSON.stringify({
    status: 'success',
    data: {
      usuarios: [
        { id: 1, nombre: 'Ana', activo: true },
        { id: 2, nombre: 'Luis', activo: false }
      ],
      paginacion: { pagina: 1, total: 2 }
    },
    timestamp: new Date().toISOString()
  });
}
function render(datos){
  const tbody = document.getElementById('tbody');
  tbody.innerHTML = '';
  datos.data.usuarios.forEach(u=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${u.id}</td><td>${u.nombre}</td><td>${u.activo ? 'Sí' : 'No'}</td>`;
    tbody.appendChild(tr);
  });
  const ts = datos.timestamp instanceof Date ? datos.timestamp.toLocaleString() : datos.timestamp;
  document.getElementById('timestamp').textContent = 'Timestamp: ' + ts;
}
document.getElementById('btn-cargar').addEventListener('click', ()=>{
  const resp = simularAPI();
  const datos = JSON.parse(resp, (k,v)=> k==='timestamp' ? new Date(v) : v);
  render(datos);
});
