# XHR POST JSON

Envía JSON con `Content-Type: application/json` y muestra la respuesta.  
Usa `https://jsonplaceholder.typicode.com/posts`, que devuelve `201 Created` con un cuerpo simulado.

**Cómo probar**  
Sirve `index.html` en local y envía el formulario.
