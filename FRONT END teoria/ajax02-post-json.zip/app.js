const form = document.getElementById("form");
const out  = document.getElementById("salida");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const datos = Object.fromEntries(new FormData(form));

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "https://jsonplaceholder.typicode.com/posts", true);
  xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

  xhr.onload = function() {
    out.textContent = "Status: " + xhr.status + "\n\n" + xhr.responseText;
  };
  xhr.onerror = function() {
    out.textContent = "Fallo de red o CORS.";
  };
  xhr.send(JSON.stringify(datos));
});
