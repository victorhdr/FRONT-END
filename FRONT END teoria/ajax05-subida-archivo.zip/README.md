# XHR subida de archivo con progreso

- Envío mediante `FormData` (sin establecer `Content-Type` manualmente).
- Progreso con `xhr.upload.onprogress`.
- Servidor de prueba incluido con Express + Multer.

**Cómo probar**  
1. `npm i express multer`  
2. `node server.js`  
3. Abre `http://localhost:3000` y sube un archivo.
