const form = document.getElementById("upload-form");
const barra = document.getElementById("barra");
const estado = document.getElementById("estado");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const file = document.getElementById("archivo").files[0];
  if (!file) { estado.textContent = "Selecciona un archivo."; return; }

  const fd = new FormData();
  fd.append("archivo", file);

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "/upload", true);

  xhr.upload.onprogress = (e) => {
    if (e.lengthComputable) {
      const pct = (e.loaded / e.total) * 100;
      barra.value = pct;
      barra.setAttribute("aria-valuenow", String(Math.round(pct)));
    }
  };
  xhr.onload = () => {
    estado.textContent = xhr.status === 200 ? "Subida completada ✔︎" : ("Error del servidor: " + xhr.status);
  };
  xhr.onerror = () => estado.textContent = "Error de conexión.";
  xhr.send(fd);
});
