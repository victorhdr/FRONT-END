document.addEventListener("DOMContentLoaded", function() {
      let latitud = 40.417;
      let longitud = -3.703;
      let zoom = 13;

      let mi_mapa = L.map("id_mapa").setView([latitud, longitud], zoom);

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "&copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors"
      }).addTo(mi_mapa);

      // Coordenadas de ejemplo en Madrid
      let puntosInteres = [
        {
          coord: [40.4169, -3.7035],
          texto: "Puerta del Sol"
        },
        {
          coord: [40.4183, -3.7123],
          texto: "Plaza Mayor"
        },
        {
          coord: [40.4138, -3.6921],
          texto: "Parque de El Retiro"
        },
        {
          coord: [40.4196, -3.6939],
          texto: "Museo del Prado"
        }
      ];

      puntosInteres.forEach(function(p) {
        L.marker(p.coord)
          .addTo(mi_mapa)
          .bindPopup(p.texto);
      });
    });
