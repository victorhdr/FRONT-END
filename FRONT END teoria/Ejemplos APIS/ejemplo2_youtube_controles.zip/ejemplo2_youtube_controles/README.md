# Ejemplo2 Youtube Controles

Este ejemplo se ha separado en tres ficheros principales:

- `index.html`: la estructura HTML de la página.
- `styles.css`: los estilos CSS propios del ejemplo.
- `app.js`: el código JavaScript que inicializa el reproductor o el mapa.

## Cómo ejecutarlo

1. Abre el fichero `index.html` con un navegador web moderno (Chrome, Firefox, Edge, etc.).
2. Asegúrate de que tienes conexión a Internet, ya que:
   - En los ejemplos de YouTube se carga un `iframe` con un vídeo alojado en YouTube.
   - En los ejemplos de mapas se cargan librerías y tiles de OpenStreetMap/Leaflet desde CDNs.

No es necesario instalar nada adicional: basta con mantener juntos estos tres ficheros
en la misma carpeta y abrir `index.html`.
