// Carga asíncrona del API de YouTube
    let tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    let firstScriptTag = document.getElementsByTagName("script")[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

    let player;

    function onYouTubeIframeAPIReady() {
      player = new YT.Player("mi_reproductor", {
        height: "480",
        width: "854",
        videoId: "lKCCZTUx0sI"
      });
    }

    function playVideo() {
      if (player) player.playVideo();
    }

    function pauseVideo() {
      if (player) player.pauseVideo();
    }

    function muteVideo() {
      if (player) player.mute();
    }

    function unmuteVideo() {
      if (player) player.unMute();
    }
