document.addEventListener("DOMContentLoaded", function() {
      let latitud = 40.417;   // coordenada Y (latitud)
      let longitud = -3.703;  // coordenada X (longitud)
      let zoom = 13;

      let mi_mapa = L.map("id_mapa").setView([latitud, longitud], zoom);

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "&copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors"
      }).addTo(mi_mapa);
    });
