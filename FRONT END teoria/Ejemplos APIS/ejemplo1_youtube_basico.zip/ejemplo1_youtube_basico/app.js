let tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    let firstScriptTag = document.getElementsByTagName("script")[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

    let player;

    function onYouTubeIframeAPIReady() {
      player = new YT.Player("mi_reproductor", {
        height: "480",
        width: "854",
        videoId: "lKCCZTUx0sI",
        events: {
          "onReady": onPlayerReady
        }
      });
    }

    function onPlayerReady(event) {
      event.target.playVideo();
    }
