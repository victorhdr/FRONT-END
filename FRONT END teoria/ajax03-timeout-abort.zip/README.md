# XHR timeout y abort()

Muestra cómo:
- Establecer `xhr.timeout` y manejar `ontimeout`.
- Cancelar con `xhr.abort()`.

**Cómo probar**  
1) Pulsa *Llamada lenta*: se invoca `https://httpbin.org/delay/5`.  
2) Antes de 3s verás timeout; o pulsa *Cancelar* para abortar.
