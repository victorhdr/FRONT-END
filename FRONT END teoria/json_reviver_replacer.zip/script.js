
'use strict';
document.getElementById('btn-ejecutar').addEventListener('click', ()=>{
  const usuario = { nombre:'Carlos', password:'secreto', fecha: new Date().toISOString() };
  document.getElementById('out-original').textContent = JSON.stringify(usuario, null, 2);

  const ocultandoPassword = JSON.stringify(usuario, (k,v)=> k==='password' ? undefined : v, 2);
  document.getElementById('out-replacer').textContent = ocultandoPassword;

  const parsed = JSON.parse(ocultandoPassword, (k,v)=> k==='fecha' ? new Date(v) : v);
  document.getElementById('out-reviver').textContent = JSON.stringify({
    ...parsed,
    fechaTipo: parsed.fecha instanceof Date ? 'Date' : typeof parsed.fecha
  }, null, 2);
});
