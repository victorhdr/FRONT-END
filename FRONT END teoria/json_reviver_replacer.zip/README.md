
# json_reviver_replacer
Muestra cómo ocultar campos sensibles con `replacer` al serializar y cómo transformar propiedades (p.ej. fechas) con `reviver` al parsear.
