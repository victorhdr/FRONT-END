# XHR GET básico

Demuestra el flujo mínimo con `XMLHttpRequest`:

1. Crear instancia  
2. `open("GET", url)`  
3. Registrar `onreadystatechange`  
4. `send()`

**Cómo probar**  
Abre `index.html` en un servidor local (por ejemplo, con la extensión Live Server de VS Code).

**Qué hace**  
Consulta `https://jsonplaceholder.typicode.com/posts/1` y muestra el JSON formateado.
