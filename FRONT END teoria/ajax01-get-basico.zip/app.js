document.getElementById("btn").addEventListener("click", () => {
  const pre = document.getElementById("salida");
  pre.textContent = "Cargando…";

  var xhr = new XMLHttpRequest();
  xhr.open("GET", "https://jsonplaceholder.typicode.com/posts/1", true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        try {
          const data = JSON.parse(xhr.responseText);
          pre.textContent = JSON.stringify(data, null, 2);
        } catch (e) {
          pre.textContent = "Respuesta no JSON";
        }
      } else {
        pre.textContent = "Error HTTP: " + xhr.status + " " + xhr.statusText;
      }
    }
  };
  xhr.onerror = () => pre.textContent = "Fallo de red o CORS.";
  xhr.send();
});
