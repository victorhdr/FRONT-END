
'use strict';
document.getElementById('btn-ejecutar').addEventListener('click', () => {
  const usuario = { nombre: 'Ana', edad: 30, activo: true };
  const compacta = JSON.stringify(usuario);
  const pretty = JSON.stringify(usuario, null, 2);
  console.log('Compacta:', compacta);
  console.log('Pretty:', pretty);
  document.getElementById('out-compacta').textContent = compacta;
  document.getElementById('out-pretty').textContent = pretty;

  const obj = {
    nombre: 'Juan',
    indefinido: undefined,
    metodo() { console.log('hola'); }
  };
  const omitidos = JSON.stringify(obj, null, 2);
  console.log('Omitidos (undefined/funciones):', omitidos);
  document.getElementById('out-omitidos').textContent = omitidos;
});
