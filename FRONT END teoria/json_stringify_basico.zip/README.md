
# json_stringify_basico
Demuestra `JSON.stringify()` con y sin indentación, y cómo `undefined` y funciones se **omiten** al serializar.
Abrir `index.html` y pulsar **Ejecutar ejemplo**.
