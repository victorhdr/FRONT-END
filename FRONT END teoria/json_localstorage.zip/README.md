
# json_localstorage
Persistencia de una configuración sencilla en `localStorage` usando `JSON.stringify()` y `JSON.parse()` con `reviver` para reconstruir `Date`.
