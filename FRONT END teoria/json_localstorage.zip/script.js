
'use strict';
const KEY = 'config';
function guardar(){
  const configuracion = {
    tema: document.getElementById('tema').value,
    notificaciones: document.getElementById('notificaciones').checked,
    ultimoAcceso: new Date()
  };
  localStorage.setItem(KEY, JSON.stringify(configuracion));
  document.getElementById('out').textContent = 'Guardado: ' + JSON.stringify(configuracion, null, 2);
}
function cargar(){
  const raw = localStorage.getItem(KEY);
  const cfg = raw ? JSON.parse(raw, (k,v)=> k==='ultimoAcceso' ? new Date(v) : v) : null;
  document.getElementById('out').textContent = cfg ? JSON.stringify({
    ...cfg,
    ultimoAccesoTipo: cfg.ultimoAcceso instanceof Date ? 'Date' : typeof cfg.ultimoAcceso
  }, null, 2) : '(sin datos)';
  if(cfg){
    document.getElementById('tema').value = cfg.tema;
    document.getElementById('notificaciones').checked = !!cfg.notificaciones;
  }
}
document.getElementById('btn-guardar').addEventListener('click', guardar);
document.getElementById('btn-cargar').addEventListener('click', cargar);
