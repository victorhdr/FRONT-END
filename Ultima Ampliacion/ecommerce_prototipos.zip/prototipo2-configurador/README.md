# Prototipo 2 - Configurador de Producto

Este ejemplo muestra un configurador muy básico de un producto (por ejemplo, unas zapatillas).

## Qué se quiere ilustrar

- Cómo recoger datos de varios controles del formulario (select, checkbox).
- Cómo calcular un precio en función de la configuración.
- Cómo generar un objeto de configuración y mostrarlo como JSON.
- Cómo actualizar una "vista previa" en tiempo real.

## Cómo probarlo

1. Abre `index.html` en el navegador.
2. Cambia el color, la talla y los extras.
3. Observa cómo cambia:
   - el texto de vista previa,
   - el precio estimado,
   - y el JSON generado en la parte inferior.

## Para el alumno

- Añade más opciones (por ejemplo, tipo de suela, edición limitada, etc.).
- Envía el JSON mediante `fetch` a tu backend para añadir el producto al carrito.
- Conecta este configurador con el resto del flujo de tu e-commerce.
