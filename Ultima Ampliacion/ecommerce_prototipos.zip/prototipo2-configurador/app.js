// Prototipo 2: Configurador de producto
// Se ilustra cómo generar un objeto de configuración y actualizar la vista previa.

const colorSelect = document.getElementById("color");
const sizeSelect = document.getElementById("size");
const extrasCheckboxes = document.querySelectorAll('input[type="checkbox"]');

const previewText = document.getElementById("previewText");
const priceEl = document.getElementById("price");
const jsonOutput = document.getElementById("jsonOutput");

const basePrice = 50;

function updateConfig() {
    const color = colorSelect.value;
    const size = sizeSelect.value;
    const extras = Array.from(extrasCheckboxes)
        .filter(chk => chk.checked)
        .map(chk => chk.value);

    const price = calculatePrice(basePrice, size, extras);

    const config = {
        productId: "ZAP-123",
        color,
        size,
        extras,
        price
    };

    // Actualizar vista previa de texto
    previewText.textContent = `Zapatilla color ${color}, talla ${size}, extras: ${extras.join(", ") || "ninguno"}.`;

    // Actualizar precio
    priceEl.textContent = price.toFixed(2);

    // Mostrar JSON
    jsonOutput.textContent = JSON.stringify(config, null, 2);
}

function calculatePrice(base, size, extras) {
    let finalPrice = base;

    if (size === "M") finalPrice += 5;
    if (size === "L") finalPrice += 10;

    extras.forEach(extra => {
        if (extra === "plantilla") finalPrice += 7;
        if (extra === "cordones") finalPrice += 3;
    });

    return finalPrice;
}

colorSelect.addEventListener("change", updateConfig);
sizeSelect.addEventListener("change", updateConfig);
extrasCheckboxes.forEach(chk => chk.addEventListener("change", updateConfig));

// Inicializar
updateConfig();
