// Prototipo 1: Sistema de recomendaciones con "AJAX" simulado
// En un proyecto real esto sería un fetch('/api/recommendations?query=...')
// Aquí usamos setTimeout y un array local para simplificar.

const searchInput = document.getElementById("search");
const btnSearch = document.getElementById("btnSearch");
const statusEl = document.getElementById("status");
const resultsList = document.getElementById("resultsList");

btnSearch.addEventListener("click", () => {
    const query = searchInput.value.trim();
    if (!query) {
        statusEl.textContent = "Escribe algo para buscar recomendaciones.";
        resultsList.innerHTML = "";
        return;
    }

    statusEl.textContent = "Buscando recomendaciones (simulación AJAX)...";
    resultsList.innerHTML = "";

    // Simulación de llamada AJAX
    setTimeout(() => {
        const data = getMockRecommendations(query);
        renderRecommendations(data, query);
    }, 700);
});

function getMockRecommendations(query) {
    const mock = [
        { name: "Zapatillas deportivas básicas", score: 0.85 },
        { name: "Zapatillas running pro", score: 0.92 },
        { name: "Calcetines técnicos deportivos", score: 0.78 }
    ];
    // En un caso real filtraríamos por "query". Aquí solo devolvemos el array.
    return mock;
}

function renderRecommendations(items, query) {
    if (!items.length) {
        statusEl.textContent = `No se encontraron recomendaciones para "${query}".`;
        return;
    }

    statusEl.textContent = `Recomendaciones para "${query}":`;
    resultsList.innerHTML = "";

    items.forEach(item => {
        const li = document.createElement("li");
        li.textContent = item.name;

        const badge = document.createElement("span");
        badge.className = "badge";
        badge.textContent = `score: ${item.score}`;
        li.appendChild(badge);

        resultsList.appendChild(li);
    });
}
