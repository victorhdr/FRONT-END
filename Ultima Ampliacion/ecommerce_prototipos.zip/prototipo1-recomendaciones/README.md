# Prototipo 1 - Sistema de Recomendaciones

Este ejemplo muestra una **demo muy sencilla** de un sistema de recomendaciones
para un e-commerce.

## Qué se quiere ilustrar

- Búsqueda por texto.
- Llamada AJAX simulada (en un proyecto real sería `fetch` a una API).
- Procesar un array de resultados (como si vinieran en JSON).
- Renderizar recomendaciones dinámicamente en el DOM.

## Cómo probarlo

1. Abre `index.html` en el navegador.
2. Escribe algún texto en el campo de búsqueda.
3. Haz clic en "Buscar recomendaciones".
4. Observa cómo se actualiza la lista de resultados y el mensaje de estado.

## Para el alumno

- Sustituye la función `getMockRecommendations()` por una llamada real a tu API.
- Aplica tus propios estilos en `styles.css`.
- Integra este componente dentro de tu e-commerce (cabecera, catálogo, etc.).
