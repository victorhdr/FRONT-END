// Prototipo 3: Panel de usuario con actividad reciente

const btnLoad = document.getElementById("btnLoad");
const statusEl = document.getElementById("status");
const activityBody = document.getElementById("activityBody");
const totalActionsEl = document.getElementById("totalActions");
const lastActionEl = document.getElementById("lastAction");

btnLoad.addEventListener("click", () => {
    statusEl.textContent = "Cargando datos (simulación AJAX)...";
    activityBody.innerHTML = "";
    totalActionsEl.textContent = "0";
    lastActionEl.textContent = "-";

    // Simulación de llamada AJAX
    setTimeout(() => {
        const data = getMockActivity();
        renderActivity(data);
    }, 800);
});

function getMockActivity() {
    // En un caso real, estos datos vendrían de una API en formato JSON
    return [
        { date: "2025-06-10", action: "Compra", detail: "Pedido #1234 (2 productos)" },
        { date: "2025-06-09", action: "Login", detail: "Inicio de sesión desde Chrome" },
        { date: "2025-06-08", action: "Wishlist", detail: "Añadido 'Zapatillas X'" }
    ];
}

function renderActivity(items) {
    if (!items.length) {
        statusEl.textContent = "No hay actividad reciente.";
        return;
    }

    statusEl.textContent = "Actividad cargada correctamente.";

    items.forEach(item => {
        const tr = document.createElement("tr");

        const tdDate = document.createElement("td");
        tdDate.textContent = item.date;

        const tdAction = document.createElement("td");
        tdAction.textContent = item.action;

        const tdDetail = document.createElement("td");
        tdDetail.textContent = item.detail;

        tr.appendChild(tdDate);
        tr.appendChild(tdAction);
        tr.appendChild(tdDetail);

        activityBody.appendChild(tr);
    });

    totalActionsEl.textContent = items.length.toString();
    lastActionEl.textContent = items[0].action;
}
