# Prototipo 3 - Panel de Usuario

Este ejemplo muestra un pequeño panel de usuario con "actividad reciente".

## Qué se quiere ilustrar

- Uso de un botón para lanzar una carga de datos (simulación de AJAX).
- Procesar una lista de objetos con fecha, acción y detalle.
- Rellenar una tabla HTML dinámicamente.
- Mostrar un resumen con:
  - número total de acciones,
  - última acción realizada.

## Cómo probarlo

1. Abre `index.html` en el navegador.
2. Haz clic en "Cargar actividad reciente".
3. Observa cómo se llena la tabla y se actualiza el resumen.

## Para el alumno

- Sustituye `getMockActivity()` por una llamada real a tu API:
  - `fetch('/api/user/activity').then(r => r.json())...`
- Añade más columnas (por ejemplo, IP, importe total, etc.).
- Muestra gráficos a partir de estos datos (barras, líneas, etc.).
