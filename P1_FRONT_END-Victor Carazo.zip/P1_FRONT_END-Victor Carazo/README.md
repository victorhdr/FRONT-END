### 📄 `README.md`


```markdown
# Práctica 1: Login en un E-commerce


## Descripción
Este proyecto implementa un sistema de **login accesible, usable y responsivo** para un sitio de comercio electrónico. Está desarrollado con **HTML5, CSS3, Bootstrap 5.3.8 y JavaScript**.


## Estructura del proyecto
```
login-ecommerce/
├── index.html
├── registro.html
├── css/
│ └── styles.css
├── js/
│ └── script.js
├── img/
│ ├── logo.png
│ ├── logo2.jpg
| └── logo3.jpg
├── README.md
```


## Tecnologías utilizadas
- **HTML5 semántico** para mejorar accesibilidad y SEO.
- **CSS3 con Flexbox, Grid y variables personalizadas**.
- **Bootstrap 5.3.8** para maquetación, formularios y validación.
- **JavaScript** para validaciones dinámicas y mejora de la experiencia del usuario.


## Responsive Design
Diseñado con un enfoque **mobile-first**, adaptándose a:
- 📱 Móvil: 320–767 px
- 💻 Tablet: 768–1023 px
- 🖥️ Escritorio: 1024 px en adelante


## Accesibilidad
- Navegación por teclado (`tabindex`, `focus-visible`)
- Etiquetas `aria-*` para lectores de pantalla
- Contraste mínimo de 4.5:1 entre texto y fondo


## Indicadores de rendimiento
- Bundle (gzip): ≤ 360 KB
- FCP ≤ 1.8 s
- LCP ≤ 2.5 s
- FID ≤ 100 ms
- CLS ≤ 0.1


## Buenas prácticas
- Separación de responsabilidades (HTML, CSS, JS)
- Nombres de clases con metodología **BEM**
- Código limpio, comentado y modular


## Ejecución
1. Clona el repositorio o descarga el proyecto.
2. Abre `index.html` en tu navegador.
3. (Opcional) Usa un servidor local (VS Code Live Server o similar).


## Autor
Proyecto realizado por **Víctor Carazo** — Curso 2025–2026.
```