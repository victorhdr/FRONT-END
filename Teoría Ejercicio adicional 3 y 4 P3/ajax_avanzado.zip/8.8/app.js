"use strict";

(function () {
  const API_BASE = "https://api.ecommerce-rendimiento.com";

  const inputBusquedaEl = document.querySelector("#busqueda");
  const btnResetEl = document.querySelector("#btn-reset");
  const listaEl = document.querySelector("#lista");
  const estadoEl = document.querySelector("#estado");
  const sentinelaEl = document.querySelector("#sentinela");

  let pagina = 1;
  let terminoActual = "";
  let cargando = false;
  let hayMas = true;

  /**
   * Caché simple:
   * clave = término de búsqueda + página
   */
  const cache = Object.create(null);

  function setEstado(tipo, mensaje) {
    estadoEl.className =
      tipo === "error" ? "error" : tipo === "info" ? "info" : "ok";
    estadoEl.textContent = mensaje;
  }

  function debounce(fn, delay) {
    let timerId;
    return function (...args) {
      window.clearTimeout(timerId);
      timerId = window.setTimeout(() => fn.apply(this, args), delay);
    };
  }

  function limpiarLista() {
    listaEl.innerHTML = "";
    pagina = 1;
    hayMas = true;
  }

  async function cargarPagina() {
    if (cargando || !hayMas) return;
    cargando = true;
    setEstado("info", "Cargando productos...");

    const claveCache = `${terminoActual}::${pagina}`;

    try {
      if (cache[claveCache]) {
        renderProductos(cache[claveCache], pagina === 1);
        setEstado("ok", "Productos desde caché local.");
      } else {
        const params = new URLSearchParams({ page: String(pagina) });

        if (terminoActual) {
          params.set("q", terminoActual);
        }

        const url = `${API_BASE}/productos?${params.toString()}`;
        const response = await fetch(url, {
          headers: { Accept: "application/json" },
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();
        cache[claveCache] = data;
        renderProductos(data, pagina === 1);
        setEstado("ok", `Productos cargados (página ${pagina}).`);
      }

      pagina += 1;
    } catch (error) {
      console.error(error);
      setEstado("error", "No se pudieron cargar más productos.");
      hayMas = false;
    } finally {
      cargando = false;
    }
  }

  function renderProductos(data, esPrimeraPagina) {
    const items = Array.isArray(data?.items) ? data.items : [];

    if (items.length === 0) {
      if (esPrimeraPagina) {
        listaEl.innerHTML = "<p>No se han encontrado productos.</p>";
      }
      hayMas = false;
      return;
    }

    for (const producto of items) {
      const article = document.createElement("article");
      article.className = "card";
      article.innerHTML = `
        <h3>${producto.nombre}</h3>
        <p class="price">${producto.precio.toFixed(2)} €</p>
        <p>${producto.descripcion}</p>
      `;
      listaEl.appendChild(article);
    }

    hayMas = Boolean(data.hasMore);
  }

  const onBuscar = debounce(() => {
    terminoActual = inputBusquedaEl.value.trim();
    limpiarLista();
    cargarPagina();
  }, 400);

  inputBusquedaEl.addEventListener("input", onBuscar);

  btnResetEl.addEventListener("click", () => {
    inputBusquedaEl.value = "";
    terminoActual = "";
    limpiarLista();
    cargarPagina();
  });

  const observer = new IntersectionObserver(
    (entries) => {
      const [entry] = entries;
      if (entry.isIntersecting) {
        cargarPagina();
      }
    },
    { rootMargin: "200px" },
  );

  observer.observe(sentinelaEl);

  // Primera carga
  cargarPagina();
})();
