"use strict";

(function () {
  const estadoEl = document.querySelector("#estado");
  const listaOpinionesEl = document.querySelector("#lista-opiniones");
  const formEl = document.querySelector("#form-opinion");
  const textareaEl = document.querySelector("#texto-opinion");

  // En un e-commerce real, este token CSRF vendría del backend y se incluiría,
  // por ejemplo, en una meta tag o en el HTML renderizado en servidor.
  const CSRF_TOKEN = "ejemplo-csrf-token";
  const AUTH_TOKEN = "Bearer EJEMPLO_JWT";
  const API_URL =
    "https://api.ecommerce-seguro.com/productos/123/opiniones";

  function setEstado(tipo, mensaje) {
    estadoEl.className = tipo === "error" ? "error" : "ok";
    estadoEl.textContent = mensaje;
  }

  // Simula que el backend nos devuelve opiniones ya almacenadas
  let opiniones = [
    { id: 1, texto: "Buen producto, llegó rápido." },
    { id: 2, texto: "La calidad es mejor de lo esperado." },
  ];

  function renderOpiniones() {
    const existentes = listaOpinionesEl.querySelectorAll(".opinion");
    existentes.forEach((elemento) => elemento.remove());

    for (const opinion of opiniones) {
      const div = document.createElement("div");
      div.className = "opinion";
      // Inserción segura: usamos textContent, NO innerHTML
      div.textContent = opinion.texto;
      listaOpinionesEl.appendChild(div);
    }
  }

  async function enviarOpinion(event) {
    event.preventDefault();

    const texto = (textareaEl.value || "").toString().trim();

    if (!texto) {
      setEstado("error", "La opinión no puede estar vacía.");
      return;
    }

    setEstado("ok", "Enviando opinión...");

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": CSRF_TOKEN,
          Authorization: AUTH_TOKEN,
        },
        body: JSON.stringify({ texto }),
      });

      // En fetch, errores HTTP no lanzan excepción automáticamente
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const nuevaOpinion = await response.json();

      // Aunque el backend debería sanitizar, en el cliente seguimos
      // insertando como texto plano para reducir riesgos.
      opiniones.unshift({
        id: nuevaOpinion.id,
        texto: nuevaOpinion.texto,
      });

      renderOpiniones();
      setEstado("ok", "Opinión enviada correctamente.");
      formEl.reset();
    } catch (error) {
      console.error(error);
      setEstado(
        "error",
        "No se pudo enviar la opinión. Inténtalo de nuevo.",
      );
    }
  }

  renderOpiniones();
  formEl.addEventListener("submit", enviarOpinion);
})();
