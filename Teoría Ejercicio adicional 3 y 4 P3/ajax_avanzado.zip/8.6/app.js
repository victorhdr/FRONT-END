"use strict";

(function () {
  const tbodyCarritoEl = document.querySelector("#tbody-carrito");
  const totalEl = document.querySelector("#total");
  const spinnerEl = document.querySelector("#spinner");
  const estadoEl = document.querySelector("#estado");
  const estadoAccesibleEl = document.querySelector("#estado-accesible");

  /** Estado en memoria del carrito */
  let lineas = [
    { id: 1, nombre: "Zapatillas Running", cantidad: 1, precio: 79.95 },
    { id: 2, nombre: "Camiseta Técnica", cantidad: 2, precio: 24.5 },
  ];

  function renderCarrito() {
    tbodyCarritoEl.innerHTML = "";
    let total = 0;

    for (const linea of lineas) {
      const tr = document.createElement("tr");
      const subtotal = linea.cantidad * linea.precio;
      total += subtotal;

      tr.innerHTML = `
        <td>${linea.nombre}</td>
        <td>
          <button
            class="btn btn-sm btn-primary"
            data-accion="dec"
            data-id="${linea.id}"
            type="button"
          >
            -
          </button>
          <span style="margin: 0 0.5rem" data-cant-id="${linea.id}">
            ${linea.cantidad}
          </span>
          <button
            class="btn btn-sm btn-primary"
            data-accion="inc"
            data-id="${linea.id}"
            type="button"
          >
            +
          </button>
        </td>
        <td>${linea.precio.toFixed(2)} €</td>
        <td data-subtotal-id="${linea.id}">${subtotal.toFixed(2)} €</td>
        <td>
          <button
            class="btn btn-sm btn-danger"
            data-accion="remove"
            data-id="${linea.id}"
            type="button"
          >
            Eliminar
          </button>
        </td>
      `;

      tbodyCarritoEl.appendChild(tr);
    }

    totalEl.textContent = total.toFixed(2);
    tbodyCarritoEl
      .querySelectorAll("button[data-accion]")
      .forEach((boton) => boton.addEventListener("click", onAccion));
  }

  function setEstado(tipo, mensaje) {
    estadoEl.className = tipo === "error" ? "error" : "ok";
    estadoEl.textContent = mensaje;
    estadoAccesibleEl.textContent = mensaje;
  }

  function setCargando(estaCargando) {
    spinnerEl.style.display = estaCargando ? "inline-block" : "none";
    tbodyCarritoEl
      .querySelectorAll("button")
      .forEach((boton) => (boton.disabled = estaCargando));
  }

  /**
   * Simula una llamada AJAX al backend del carrito.
   * A veces falla aleatoriamente para que se vea la reversión de Optimistic UI.
   */
  function apiActualizarLinea(linea) {
    return new Promise((resolve, reject) => {
      const fallo = Math.random() < 0.2; // 20 % de fallos
      setTimeout(() => {
        if (fallo) reject(new Error("Fallo simulado en el servidor"));
        else resolve({ ok: true, linea });
      }, 800);
    });
  }

  async function onAccion(event) {
    const boton = event.currentTarget;
    const id = Number(boton.dataset.id);
    const accion = boton.dataset.accion;
    const lineaActual = lineas.find((linea) => linea.id === id);

    if (!lineaActual) return;

    // Copia para revertir en caso de error (Optimistic UI)
    const copiaAntes = { ...lineaActual };
    const estadoOriginal = [...lineas];

    if (accion === "inc") {
      lineaActual.cantidad += 1;
    } else if (accion === "dec") {
      lineaActual.cantidad = Math.max(1, lineaActual.cantidad - 1);
    } else if (accion === "remove") {
      lineas = lineas.filter((linea) => linea.id !== id);
    }

    renderCarrito(); // Vista optimista inmediata
    setCargando(true);
    setEstado("ok", "Actualizando carrito...");

    try {
      await apiActualizarLinea(lineaActual);
      setEstado("ok", "Carrito actualizado correctamente.");
    } catch (error) {
      console.error(error);
      // Revertimos si hubo error
      if (accion === "remove") {
        lineas = estadoOriginal;
      } else {
        const indice = lineas.findIndex((linea) => linea.id === id);
        if (indice >= 0) lineas[indice] = copiaAntes;
      }
      renderCarrito();
      setEstado(
        "error",
        "No se pudo actualizar el carrito. Se ha restaurado el estado anterior.",
      );
    } finally {
      setCargando(false);
    }
  }

  // Render inicial
  renderCarrito();
})();
